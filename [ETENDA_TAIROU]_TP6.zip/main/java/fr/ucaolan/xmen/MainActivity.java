package fr.ucaolan.xmen;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.ucaolan.xmen.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding ui;
    private List<XMen> liste;
    private XMenAdapter adapter;

    private ActivityResultLauncher<Intent> editLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        ui = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());

        editLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                this::onEditActivityFinished);

        XMenApplication application = (XMenApplication) getApplication();
        liste = application.getListe();

        adapter = new XMenAdapter(liste);
        adapter.setOnItemClickListener(this::onItemClick);

        ui.recycler.setAdapter(adapter);

        ui.recycler.hasFixedSize();

        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        ui.recycler.setLayoutManager(lm);

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(
                this, DividerItemDecoration.VERTICAL
        );
        ui.recycler.addItemDecoration(dividerItemDecoration);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        XMenApplication application = (XMenApplication) getApplication();
        int idItem = item.getItemId();
        if (idItem == R.id.reinit)
        {
            application.initListe();
            adapter.notifyDataSetChanged();
            return true;
        }
        if (idItem == R.id.create)
        {
            onEdit(-1);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int position = item.getOrder();

        switch (item.getItemId())
        {
            case XMenViewHolder.MENU_EDIT : {
                onEdit(position);
                return true;
            }

            case XMenViewHolder.MENU_DELETE : {
                onDelete(position);
                return true;
            }
        }
        return super.onContextItemSelected(item);
    }

    /**
     * Cette methode est appelée quand on revient dans cette activité
     * apres l'avoir lancé par editLauncher
     * @param result
     */
    private void onEditActivityFinished(ActivityResult result)
    {
        if (result.getResultCode() == RESULT_OK)
        {
            adapter.notifyDataSetChanged();
        }
    }

    /**
     * lancer l'edition sur un XMen par position indique si position == -1 alors creation
     * @param position index de la liste mettre -1 si on veut creer un xmen
     */
    private void onEdit(int position)
    {
        Intent editIntent = new Intent(MainActivity.this, EditActivity.class);
        editIntent.putExtra(EditActivity.EXTRA_POSITION, position);
        editLauncher.launch(editIntent);

    }

    private void onItemClick(int position)
    {
        XMen xmen = liste.get(position);
        xmen.setIdImage(R.drawable.undef);
        adapter.notifyItemChanged(position);
    }

    private void onReallyDelete(int position)
    {
        liste.remove(position);
        adapter.notifyItemRemoved(position);
    }

    private void onDelete(int position)
    {
        XMen xMen = liste.get(position);
        new AlertDialog.Builder(this)
                .setTitle(xMen.getNom())
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setMessage("Vous confirmez la suppression")
                .setPositiveButton(android.R.string.ok, (dialog, which) -> onReallyDelete(position))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}