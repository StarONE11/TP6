package fr.ucaolan.xmen;

import androidx.annotation.DrawableRes;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import java.util.List;

import fr.ucaolan.xmen.databinding.ActivityEditBinding;
import fr.ucaolan.xmen.databinding.ActivityMainBinding;

public class EditActivity extends AppCompatActivity {

    public static final String EXTRA_POSITION = "position";
    private ActivityEditBinding ui;

    private int position;
    private List<XMen> liste;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ui = ActivityEditBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        position = getIntent().getIntExtra(EXTRA_POSITION, position);

        XMenApplication application = (XMenApplication) getApplication();
        liste = application.getListe();

        if (position >=0)
        {
            setXMen(liste.get(position));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.edit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void onAccept(MenuItem item)
    {
        XMen xmen = new XMen();
        xmen.setNom(ui.editXMenName.getText().toString());
        xmen.setAlias(ui.editXMenAlias.getText().toString());
        xmen.setPouvoirs(ui.editXMenPwr.getText().toString());
        xmen.setDescription(ui.editXMenDesc.getText().toString());

        if (position >=0)
        {
            xmen.setIdImage(liste.get(position).getIdImage());
            liste.set(position, xmen);
        }
        else
        {
            liste.add(xmen);
        }

        setResult(RESULT_OK);
        finish();
    }

    public void setXMen(XMen xmen)
    {
        ui.editXMenName.setText(xmen.getNom());
        ui.editXMenAlias.setText(xmen.getAlias());
        ui.editXMenDesc.setText(xmen.getDescription());
        ui.editXMenPwr.setText(xmen.getPouvoirs());
        ui.editXMenImage.setImageResource(xmen.getIdImage());
    }
}